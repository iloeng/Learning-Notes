require 'socket'
require 'pp'
require File.join(File.dirname(__FILE__), '../lib/redis')

#require File.join(File.dirname(__FILE__), '../lib/server')


#r = Redis.new
#loop do

#    puts "--------------------------------------"
#  sleep 12
#end