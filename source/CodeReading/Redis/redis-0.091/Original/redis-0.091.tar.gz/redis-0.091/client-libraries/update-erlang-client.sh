#!/bin/sh
echo "Sorry for now this must be done by hand... don't know mercurial enough"
